# Kinetic OS - VESC LispBM script

> **WARNING: NOT VALIDATED ON HARDWARE.** This script was written against the official LispBM docs but has never been run on a VESC. Test first on a stand with the wheel off the ground, with a way to cut power. Do not ride until verified.

`kinetic.lisp` runs on the VESC itself. Ride modes, derating and the stationary-only up-shift rule are enforced locally; the phone/BLE link is only a request channel. If BLE drops, the last mode and derating keep working.

## Install
1. Connect to the VESC with VESC Tool (USB).
2. Open **VESC Dev Tools -> LispBM**.
3. Load `kinetic.lisp` into the editor, press **Upload** (or Run for a streamed, non-persistent test run first).
4. After upload, enable **Auto run** (checkbox / "Run on boot"; wording varies by VESC Tool version) so it starts at power-up.
5. Your phone app must use the VESC's custom app data (e.g. via the VESC BLE UART bridge); see `protocol.md` (v2; v1 requests still accepted).

Important: the ceiling is read with `conf-get` at script start. The script never calls `conf-store`, so limits revert on reboot. If you re-upload while the script was already running and has reduced limits, power-cycle the VESC first, otherwise the lowered values become the new ceiling.

## Install as VESC package
A VESC Tool package description lives in `vesc_pkg/kinetic/` (format of vedderb/vesc_pkg). `kinetic.lisp` stays the single source; the Makefile copies it at build time.

Build (needs the `vesc_tool` command-line binary, GPL-3.0, from vedderb/vesc_tool or an installed VESC Tool):
```
cd vesc_pkg/kinetic
make VESC_TOOL=/path/to/vesc_tool     # writes kinetic.vescpkg and dist/kinetic.vescpkg
```
Install: connect to the VESC, open **VESC Packages** (sidebar), use **Load Custom** / **Install from file** and pick `kinetic.vescpkg`, then press **Install**. Alternative without a package: use the manual LispBM upload described under Install. The package only shows as compatible on motor controllers (not VESC BMS / Express). After installing, check the script is set to run on boot, and read the warning at the top: it is not validated on hardware.

## Behaviour
- Boot: reads `l-current-max-scale`, `l-watt-max`, `l-in-current-max`, `l-max-erpm`, `l-battery-cut-start` as the **hard ceiling**. Every applied value is `min(value, ceiling)`. Starts in mode 0 (eco).
- Modes: 0 eco, 1 sport, 2 race, 3 custom1, 4 custom2. Default table = fractions of the ceiling (eco 40%, sport 70%, race 100%, custom 50%/60%). Mode scale is a fraction of the boot current scale.
- Mode change accepted if |ERPM| < `stop-erpm`, or the new mode is not more powerful in every limit (scale, watt, battery current, erpm) than the current one.
- Derating every `loop-dt` (0.1 s): linear derate from MOSFET temp, motor temp and battery voltage; applied scale = `min(mode scale, derates)`, then rate limited (fast down, slow up) and written with `conf-set 'l-current-max-scale` (RAM only).
- Watt, battery current and ERPM limits are applied on mode change; they are not derated by the script.

## Tunables (top of `kinetic.lisp`)
| Name | Default | Meaning |
|---|---|---|
| stop-erpm | 300 | stationary threshold (ERPM, not km/h; depends on pole pairs) |
| loop-dt | 0.1 | derate loop period (s) |
| derate-floor | 0.15 | minimum derate factor |
| step-down / step-up | 0.10 / 0.02 | rate limiter per tick |
| fet-start / fet-end | 70 / 90 | MOSFET degC |
| mot-start / mot-end | 90 / 120 | motor degC |
| use-mot-temp | 1 | set 0 without a motor sensor |
| v-start / v-end | 0 (auto) | auto = battery-cut-start + v-auto-margin / battery-cut-start |
| v-auto-margin | 3.0 | V |
| default mode fractions | see `m-*` lists | edit tables |

## Anti-theft lock
Phone-independent immobilizer, enforced on the VESC (commands 4/5/6 in `protocol.md`).
- Setup: set a PIN once (`cmd 6`, 4-8 digits), then `cmd 4` lock while stationary. `cmd 5` unlocks.
- Locked: the lock flag is stored in EEPROM (survives power cycles). At boot the script reads it first and immediately calls `(app-disable-output -1)` (stops ADC/PPM/UART apps driving the motor) and sets `l-current-max-scale` to 0 (RAM only, no `conf-store`). The main loop re-asserts output-off every cycle. Mode changes and derating can never re-enable output. The script never calls `set-current` or `set-brake`: the motor freewheels (the lock does not hold the wheel).
- Wrong PIN: 5 consecutive failures lock out all PIN commands for 60 s, doubling per further series, capped at 1 h. The failure count (EEPROM addr 102; 5 = lockout pending) and lockout level (addr 103; 0 = none) are persisted, written only on a failed attempt or when a success clears them. After a power cycle a pending lockout restarts from boot with its full persisted duration (so it can only get longer, never shorter, and brute force is not ~5 guesses per power cycle). The timer itself is RAM. PIN commands (4/5/6) are refused with code 3 while moving, so these writes (which stop the motor briefly) only happen stationary. Limit: an attacker with VESC Tool can still clear addresses 100-103.
- TAMPER: while locked, |ERPM| >= `stop-erpm` for more than 1 s sets a tamper flag (status byte 17 bit2), cleared on unlock. RAM only; the phone must poll status to see it. Nothing sounds an alarm.
- PIN storage: EEPROM address 101 holds `PIN xor 0x5A17C3E9`, lock flag at address 100, failure state at 102/103. This is obfuscation, not encryption.
- Recovery if the PIN is lost: VESC Tool -> LispBM -> stop/erase the script, and clear or overwrite EEPROM variables 100 and 101 (e.g. run `(eeprom-store-i 100 0)`), or reflash the VESC firmware (EEPROM does not survive firmware updates). Do not re-run the script without power-cycling while locked: conf was set to 0, and the script would read that as the new boot ceiling (power cycle restores the stored config).
- Honest limits: anyone with USB/CAN access and VESC Tool can read the EEPROM, stop the script, or just run `set-current`/write the motor config; the lock is a deterrent against casual theft and throttle-only attacks, not a security boundary. A different VESC app (or a CAN master / BMS / second controller) is not affected. EEPROM writes stop the motor briefly and are limited to ~100,000 per cell; the script writes only on lock, unlock, set-PIN and failed PIN attempts.
- Not hardware tested; verify with the wheel off the ground that (app-disable-output -1) really blocks your throttle app, and that `l-current-max-scale` 0 is accepted by your firmware.

## Neutral and parental limit
- **Neutral (cmd 7):** `app-disable-output -1`, so throttle apps are ignored and the motor freewheels (no brake current). Turning it on is always allowed; turning it off needs standstill and an unlocked vehicle. Re-asserted every loop tick, and unlock does not end it. Design choice: neutral is **not persisted**, so after a power cycle drive is enabled again (unless locked); persisting it risks a "dead" scooter after a crash/reset that the rider cannot clear without the phone.
- **Parental limit (cmd 8):** a persistent ceiling on current scale (permille) and ERPM, stored in EEPROM addr 104 (permille, absent = none) and 105 (ERPM, absent/0 = none), loaded at boot before modes are applied; effective ceiling = min(boot ceiling, parental) for all modes and custom params (watt and battery current are not limited by it). Needs the lock PIN with the same counted PIN check and lockout as cmd 4-6. Lowering while riding takes effect immediately (the EEPROM write waits for standstill, so cutting power first loses it); raising or clearing needs standstill. Refused while locked. Like the PIN, it can be cleared by anyone with VESC Tool (clear addr 104/105).

## Traction control (experimental)
Off by default; enabled per ride by protocol cmd 9 (intervention 0..100 %, RAM only, 0 after boot, so the phone re-sends it on each mode change). It can only ever REDUCE motor current: the applied scale is `min(mode/derate/rate-limit/parental scale, tc scale)`, and lock/neutral still force output off as before. Wheel spin is detected from the ERPM rise rate (only while ERPM > 0 and motor current > 0): slip threshold = `tc-max-erpm-rate * (2 - pct/100)` ERPM/s. On slip the TC scale drops by `0.15 * pct/100` per loop tick down to a floor of `1 - 0.7 * pct/100`; without slip it recovers at +0.5/s. If an IMU is present (`get-imu-acc`, wrapped in `trap`; a missing IMU is harmless) and |acc| < 0.35 g for more than 100 ms the vehicle is airborne and TC does not intervene. Status bytes 22 (percent) and 23 (bit0 intervening, bit1 airborne) report it.

**Not hardware-validated.** `tc-max-erpm-rate` (default 20000 ERPM/s) is a placeholder: tune it per vehicle on a stand with the wheel off the ground before riding with TC on. Lowering intervention while moving is refused (code 3).

## Not implemented
- **Forward/reverse crawl mode**: not implemented in LispBM. It needs app-level and hardware validation (reverse limits, direction handling, `l-min-erpm`). Document-only.
- Speed limit uses `l-max-erpm`; `max-speed` (m/s) is not touched. Reverse limits (`l-min-erpm`, `l-current-min-scale`) are untouched.
- Regen/brake limits and `l-in-current-max-scale` (FW 7.01+ only) are not used.
- Nothing is persisted (no `conf-store`), custom mode edits are lost on reboot.

## Safety notes
- Phone data can only lower or equal the boot ceiling; values above are clamped.
- VESC's own hard limits (fault codes, `l-battery-cut`, temp limits) remain active under the script.
- A crashed/stopped script leaves the last applied limits in RAM until reboot.
- Up-shift while moving is rejected (code 3), but ERPM is a motor value; wheel slip or freewheel can fool it.

## Validated in LispBM interpreter (not on hardware)
`kinetic.lisp` was run in the real LispBM REPL (svenssonjoel/lispBM master, commit `1359ac0`, "LBM Version 0.41.0", 64-bit Linux build). This proves the core-language usage and the logic; it does **not** prove anything about a VESC. The WARNING above still applies in full.

Run: `./test/run_tests.sh` (clones/builds the REPL under `/tmp/claude-0/lbm/src` if missing; override with `LBM_SRC=` or `LBM_REPL=`; needs git, gcc, make, libreadline-dev, libpng-dev). It exits non-zero on any failure. Manual build: `cd <lispBM>/repl && make FEATURES="64"`.

Files: `test/stubs.lisp` (fake `conf-get`/`conf-set`/`get-temp-fet`/`get-temp-mot`/`get-vin`/`get-rpm`/`send-data`/`event-enable` with controllable state and call logs), `test/run_tests.lisp` (302 assertions), `test/smoke.lisp` and `test/smoke_locked.lisp` (end-to-end drivers, the second boots with the lock flag already in EEPROM).

Checked (302 assertions + 9 smoke checks, all passing):
- Core syntax actually accepted by the interpreter: `defun`, `define` (also inside functions, sets the global), `let`, `cond` with `t`, `if`, `{ }` blocks, `and`/`or`/`not`, `ix`/`first`/`rest`/`cons`, `to-i`/`to-float`, `bufcreate`, `bufget/bufset` u8/i8/u16/u32/i32 (big-endian), `spawn`, `recv` pattern `(event-data-rx . (? data))` with `_` fallthrough, `loopwhile`.
- Boot ceiling read from `conf-get`, auto voltage thresholds, eco applied at start.
- Every `conf-set` value stays <= boot ceiling (incl. ceiling scale 0.8, custom params of 65535/0xFFFFFFFF, hot and cold ticks).
- Mode changes: accepted when stationary; more-powerful rejected when |erpm| >= `stop-erpm` (incl. negative erpm and exactly 300) with code 3 and `last-reject` set; less/equal-powerful accepted while moving; bad index (code 2), short packet (4), unknown command (5), bad custom slot (6).
- Custom params: decode of the 14-byte request, clamping to ceiling, no slot selection, active-slot increase rejected while moving, decrease applied immediately.
- Derating: `derate-hi`/`derate-lo` (start, midpoint, end, beyond, floor), FET/motor/voltage flags, `use-mot-temp 0`, min of all derates, mode scale as upper bound.
- Rate limiter: -0.10/tick down, +0.02/tick up, floor, recovery to mode scale.
- Status reply: 17-byte layout byte-by-byte against `protocol.md` (big-endian, signed temps/erpm), all 1001 permille and 400 vin values round-trip.
- Protocol v2 (u32 watts, 16-byte cmd 2): 120000 W accepted exactly, 4e9 W clamped to the ceiling, field byte order, short/bad-slot rejects, replies echo request version; v1 (u16 watts, 14-byte cmd 2) still works unchanged.
- Anti-theft lock: lock refused while moving / without PIN / wrong PIN; PIN validation (4-8 digits) and XOR storage; lock persists across a simulated reboot (EEPROM flag re-read, output disabled, scale 0); output stays disabled and scale 0 while locked through ticks, derating and mode attempts (cmd 1/2/6 -> code 11); unlock wrong-PIN counting, 60 s lockout, doubling, 1 h cap, lockout state persisted in EEPROM and surviving simulated reboots (never shortened, cleared by a correct PIN after expiry, bounded EEPROM writes, PIN commands refused while moving); tamper set after > 1 s motion and cleared on unlock; 19-byte reply with lock flags and lockout seconds.
- Neutral (on/off rules incl. moving and locked, output kept disabled every tick, not persisted, unlock does not end it) and parental limit (clamps modes and custom params, persists across simulated reboot, PIN/lockout/locked/moving rules, deferred write, clear, 24-byte reply layout).
- Bad magic / version not 1 or 2 / too short: no reply, no state change, no `conf-set`.
- Event handler thread via real `spawn`/`recv`/`send`; and the unmodified full script (autostart + forever loop) under a driver thread.

Not checked (needs real VESC firmware): that your firmware's LispBM is new enough for these constructs (the REPL is newer than most VESC releases), `conf-set` semantics and range checks for each parameter (the stub accepts any number; real FW may need `conf-store`/`conf-set` ordering, or ignore/limit values), whether `l-current-max-scale` etc. take effect immediately in the running motor controller, `event-data-rx` payload format and `send-data` routing over BLE, real sensor units/ranges (`get-rpm` is ERPM; `get-temp-mot` may be -1 or 0 without a sensor), timing/CPU load of the 0.1 s loop, and heap/stack limits on the VESC.

## Verified against the official docs (vedderb/bldc lispBM/README.md)
Also verified in the VESC README for the lock: `(app-disable-output ms)` (0 = enable now, -1 = disable forever, FW 6.00+), `eeprom-store-i addr n` / `eeprom-read-i addr` (i32, addr 0..127, 256 on FW 6.06; unwritten reads return nil; ~100,000 writes; motor stops briefly while writing). `bitwise-xor`, `pow` are core LispBM, not in that README.

Present: `conf-set`, `conf-get`, `conf-store` (not used), `get-temp-fet`, `get-temp-mot`, `get-vin`, `get-rpm`, `send-data`, `event-register-handler`, `event-enable`, `event-data-rx` (data = byte array), `bufget-i8/u8/i16/u16/i32/u32/f32`, `bufset-*`, `buflen`, `bufcreate`, `loopwhile`, `spawn`, `recv`, `sleep`, `abs`, and config params `l-current-max-scale`, `l-watt-max`, `l-in-current-max`, `l-max-erpm`, `l-battery-cut-start`.

Uncertain (core LispBM, not documented in that README): `defun`, `define`, `let`, `cond`, `if`, `and`/`or`/`not`, `first`/`rest`/`cons`/`ix`, `to-i`, `to-float`, `{ }` progn blocks. `bufset-i8` assumed (docs list bufset-i8). Redefining globals with `define` inside functions is assumed to work. `bufget-u32` returns possibly large values; fine for erpm < 2^28. Written with `get-batt` not used.
