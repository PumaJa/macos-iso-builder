# Progress log

| Date | Step | Result |
|---|---|---|
| 2026-11-24 | Environment analysis | Repo was a macOS ISO builder; project placed in `kinetic-os/`. SDK installed. |
| 2026-11-24 | Research (subagent) | No Stark API/VargLink; VESC 7.00 current |
| 2026-11-24 | Protocol extraction | enums generated from datatypes.h; layouts read from commands.c/buffer.c/bms.c |
| 2026-11-24 | vesc-protocol | 22 tests green (one decoder resync bug found & fixed) |
| 2026-11-24 | server (subagent) | 43 tests incl. real PostGIS integration green |
| 2026-11-24 | telemetry/vehicle | 19 tests green |
| 2026-11-24 | racing/export (subagent) | 60 tests green |
| 2026-11-24 | LispBM (subagent) | written, unvalidated |
| 2026-11-24 | Android app | compiles, debug APK built |
| 2026-11-24 | App tests (Robolectric, MockWebServer) | see TEST_RESULTS.md |
| 2026-11-24 | Docker stack + E2E smoke + Chromium dashboard | all green |
| 2026-11-24 | Emulator (TCG) | app runs; FGS start crash found & fixed; map blocked by sandbox TLS proxy |
| 2026-11-25 | LispBM in real interpreter (subagent) | 141 assertions + 5 smoke checks; rounding bug fixed; protocol v2 (u32 watts) |
| 2026-11-25 | OSRM routing (subagent) | /api/v1/route + compose profile; e2e Zurich route 7.1 km / 17 steps |
| 2026-11-25 | Throttle (ADC), odometer, Keystore token, CSV injection guard | tests green |
| 2026-11-25 | Alert notifications (WS + WorkManager) | Robolectric test green |
| 2026-11-25 | Turn-by-turn client, MP4 overlay export (Media3) | unit tests green; export instrumented on emulator |
| 2026-11-25 | Forum research (subagent) + decisions | docs/USER_WISHES.md, 9 wishes built, 3 declined with reasons |
| 2026-11-25 | PiP cockpit, warnings (TTS/vibration), dash tiles, sun theme, chemistry + coulomb SoC | tests green |
| 2026-11-25 | App ↔ on-vehicle script bridge, VESC setup check, kinetic.vescpkg (subagent built VESC Tool 7.01) | E2E via simulator green |
| 2026-11-25 | Anti-theft lock (LispBM via subagent + app/server/sim) | 223+9 LispBM, 145 Android, 52 server green; vescpkg rebuilt |
| 2026-11-25 | German UI (subagent), code review (subagent, 19 findings) → safety fixes, PIN lockout persisted (subagent), release signing + ABI splits | all suites green |
| 2026-11-25 | Full test run + gallery (17 screens), emulator, web dashboard with data; swipe mode change + curve point editor | all green; 3 bugs found & fixed |
| 2026-11-25 | Stark feature set from user images: home, stats (airtime/g-force), M1–M5 with PS/kW, riding time, neutral, parental lock, brightness, FR/IT/ES/SV (subagent), VargLink invite links | all green (see TEST_RESULTS) |
| 2026-11-25 | Redesign (greyscale, Barlow Condensed, own K mark), landscape layouts, personalisation (background, logo, name, accent), new lock screen with PIN pad | see TEST_RESULTS |
| 2026-11-25 | Premium pass: Barlow light numerals, hairlines; no nav bars (hub + back arrow); home tiles selectable with own photos; text size | all green |
| 2026-11-25 | Final polish: cached photo loading (hero always shows), localised race accuracy note, gallery state reset | all green |
| 2026-11-25 | Stark 2026 parity for VESC: traction control (LispBM via subagent, cmd 9, 24-byte status) + app slider/pill/gate/simulator, version history, min power, charging card | see TEST_RESULTS |
| 2026-11-26 | Stark-style mode slots (M1–M5 values + sliders, built-in overrides with factory reset), charging card in simulator, gallery: editor, charging, version history | all green |
| 2026-11-26 | New "Apex" logo + Ring/Tile variants, design presets OLED/Graphite/Titanium, M-slot on cockpit, DESIGN_BRIEF.md for OpenClaw/local model | all green |
