# Security & safety architecture

## Vehicle safety (highest priority)
| Rule | Enforcement |
|---|---|
| Throttle, brakes, motor control never depend on the phone | App sends **no** `SET_CURRENT/DUTY/RPM` commands at all. Only `SET_MCCONF_TEMP` (limits) is ever written. |
| Writes only through one audited path | `SafetyGate` issues a single-use `WriteToken`; `VescClient.writeAckedChecked` requires it. UI code cannot build writes. |
| Never exceed configured hardware limits | On every connect the runtime limits are read (`GET_MCCONF_TEMP`) and reconciled with the backup: if the VESC rebooted since the app's last write (VESC uptime), the fresh values *are* the stored config and replace the backup (so lowering limits in VESC Tool is always respected); without uptime (old FW) the element-wise minimum is used. Controllers without a UUID are refused. All mode values are fractions ≤ 1 of that backup; firmware additionally clamps current scales to 0..1. |
| Reversible | `store = 0` on every write → RAM only. Power-cycling the VESC returns to stock. "Restore stock" re-writes the backup exactly. |
| Incompatible firmware | Writes blocked unless FW 5.03–7.x (layout verified in source) and the backup UUID matches the connected controller. |
| Safe states only | Power increases (incl. stronger regen, higher reverse speed, *restore stock* and derating recovery) only below 2 km/h with known speed; unknown speed = moving. While moving a mode change reduces drive power immediately and holds regen until standstill. One mutex serialises all writes; a failed/unconfirmed write is treated as "stock" (most powerful) for the next decision. If the vehicle script was seen but stops answering, the app refuses to write instead of bypassing it. Script/lock replies must echo the command and show the expected state. |
| Unvalidated assistance | Virtual flywheel, traction control, wheelie control are refused by the gate until hardware validation exists. |
| Link loss | Limits stay as last applied (≤ stock). The LispBM script keeps derating locally without the phone. |
| Simulated data | Never mixed into real rides; flagged `source:"simulated"` in telematics; magenta UI. |

## Anti-theft lock (immobilizer)
* Runs in `kinetic.lisp` on the VESC: works without the phone, persists in EEPROM across power cycles.
* Engages **only at standstill** (checked by the app's SafetyGate *and* by the script); never applies brake current.
* While locked: throttle apps disabled (`app-disable-output`), motor current scale 0, ride-mode commands refused,
  wheel movement > 1 s sets a tamper flag → spoken/critical warning on the cockpit and `theft` alert on the server.
* Unlock needs the PIN (4–8 digits); 5 wrong PINs → 60 s lockout, doubling up to 1 h.
* **Limits (honest):** this is a deterrent. The PIN is stored on the controller (obfuscated, not encrypted); anyone with
  VESC Tool access to the controller (USB, or BLE without a BLE PIN) can stop the script and clear the lock. Set a
  VESC BLE pin and keep the controller physically inaccessible. Recovery when the PIN is lost: lispbm/README.md.

## App security
* HTTPS enforced by `network_security_config` (cleartext only for localhost/emulator/`.local`/`.lan`/`home.arpa` during NAS setup).
* JWT encrypted with AES-256-GCM using a non-exportable Android Keystore key (`TokenCipher`), stored in app-private DataStore.
* CSV exports neutralise spreadsheet formula injection (`=`, `+`, `-`, `@` prefixed text cells).
* BLE: VESC modules use their own pairing/PIN (`COMM_SET_BLE_PIN`); the app does not weaken it. BLE link-layer encryption
  depends on the module.
* No remote motor control endpoint exists on the server or in the app (verified by server test `no control endpoints`).
* GPX import parser rejects DOCTYPE/external entities (XXE tests).

## Server security
bcrypt password hashing, HS256 JWT (alg=none rejected – tested), zod validation of every body and WS message, per-route rate
limits, private groups readable only by members, telematics owner-only, photo access limited to owner/shared group members,
non-root container, HTTPS via Caddy (Let's Encrypt) or any reverse proxy, secrets only via environment (`JWT_SECRET` required).
